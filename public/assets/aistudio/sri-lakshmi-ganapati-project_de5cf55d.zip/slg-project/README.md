# Sri Lakshmi Ganapati - Village Finance Manager

React + Vite app for a weekly village micro-lending business
(Monday/Tuesday visits, 12-week loans, Paid / Skip / Short / Extra tracking).

## Run on your laptop
    npm install
    npm run dev          (opens http://localhost:5173)

## Build check (always do this before deploying)
    npm run build

## Deploy
Push to GitHub (main branch). Vercel builds it automatically.
Vercel project settings must be:
  Framework Preset : Vite
  Build Command    : npm run build
  Output Directory : dist
  Install Command  : npm install

## VERY IMPORTANT - the client's real data
All data is stored in the client's phone browser (localStorage), tied to the
website address (sri-lakshmi-ganapati.vercel.app). Keys used:
  slg_data, slg_cols, slg_exp, slg_pin, slg_newloans, slg_personal
Do NOT rename these keys and do NOT change the website address
unless a backup/restore feature has been added and tested first.
Clearing Chrome data on the phone also erases everything.

Default PIN: 1234 (client changes it in Settings).
